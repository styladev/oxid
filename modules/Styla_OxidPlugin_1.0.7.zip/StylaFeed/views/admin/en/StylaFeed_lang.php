<?php

$sLangName = "English";

$aLang = array(
    'charset'   => 'UTF-8',
    'SHOP_MODULE_GROUP_styla_api'           => 'API Settings',
    'SHOP_MODULE_GROUP_styla_feed'          => 'Feed Settings',
    'SHOP_MODULE_styla_api_key'             => 'API Key',
    'SHOP_MODULE_styla_feed_basedir'        => 'Base directory',
    'SHOP_MODULE_styla_page_size'           => 'Page size',
    'SHOP_MODULE_styla_image_attribute'     => 'Image Attribute',
    'SHOP_MODULE_styla_image_width'         => 'Image Width',
    'SHOP_MODULE_styla_image_height'        => 'Image Height',
    'SHOP_MODULE_styla_extra_attributes'    => 'Extra Attributes',
    'SHOP_MODULE_styla_feed_cache_ttl'      => 'Cache-lifetime (seconds)',
);
