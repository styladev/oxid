<?php
$this->applicationId = 'STYLAFEED';
$this->moduleVersion = '1.0.7';
