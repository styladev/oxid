<?php

$sLangName = "English";

$aLang = array(
    'charset'   => 'UTF-8',
);
