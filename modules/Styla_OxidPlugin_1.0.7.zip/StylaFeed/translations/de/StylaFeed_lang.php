<?php

$sLangName = "Deutsch";

$aLang = array(
    'charset'   => 'UTF-8',
);
