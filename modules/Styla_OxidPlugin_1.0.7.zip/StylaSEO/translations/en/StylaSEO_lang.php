<?php

$sLangName = "English";

$aLang = array(
    'charset'   => 'UTF-8',
    'STYLA_SEO_ERROR_NOUSERNAME'        => 'Error: Styla/Amazine Username is not configured.'
);
