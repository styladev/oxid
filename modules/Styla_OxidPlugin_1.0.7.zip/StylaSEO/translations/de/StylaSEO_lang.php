<?php

$sLangName = "Deutsch";

$aLang = array(
    'charset'   => 'UTF-8',
    'STYLA_SEO_ERROR_NOUSERNAME'        => 'Fehler: Styla/Amazine Username nicht konfiguriert.'
);
