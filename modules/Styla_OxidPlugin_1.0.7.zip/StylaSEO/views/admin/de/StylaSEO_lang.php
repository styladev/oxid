<?php

$sLangName = "Deutsch";

$aLang = array(
    'charset'   => 'UTF-8',
    'SHOP_MODULE_GROUP_styla_general'   => 'Styla Settings',
    'SHOP_MODULE_styla_username'        => 'Styla/Amazine Username',
    'SHOP_MODULE_styla_source_url'      => 'Source URL',
    'SHOP_MODULE_styla_js_url'          => 'JS Snippet URL',
    'SHOP_MODULE_styla_seo_basedir'     => 'Base directory',
    'SHOP_MODULE_styla_seo_cache_ttl'   => 'Cache-Lebensdauer (Sekunden)',
);
