<?php
$this->applicationId = 'STYLASEO';
$this->moduleVersion = '1.0.7';
